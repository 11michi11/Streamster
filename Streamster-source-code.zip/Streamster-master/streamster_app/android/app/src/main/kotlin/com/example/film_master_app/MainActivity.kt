package com.example.film_master_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
