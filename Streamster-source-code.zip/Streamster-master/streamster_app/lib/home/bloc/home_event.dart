import 'package:equatable/equatable.dart';
import 'package:flutter/cupertino.dart';
import 'package:streamster_app/common/common.dart';

abstract class HomeEvent extends Equatable {
  const HomeEvent();
}
