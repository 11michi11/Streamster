import 'package:equatable/equatable.dart';
import 'package:streamster_app/common/model/user.dart';

class HomeState extends Equatable {
  const HomeState._();

  const HomeState.init() : this._();

  @override
  List<Object> get props => [];
}
