import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../preferences.dart';

class PreferencesWeb extends StatefulWidget {
  final PreferencesState state;

  PreferencesWeb(this.state);

  @override
  State<StatefulWidget> createState() => _PreferencesWebState();
}

class _PreferencesWebState extends State<PreferencesWeb> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
