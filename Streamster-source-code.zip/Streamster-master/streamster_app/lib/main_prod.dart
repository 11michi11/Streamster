import 'package:streamster_app/main.dart' as App;

void main() {
  App.main(env: 'prod');
}
