package com.streamster.commons.model;

public enum GroupRoleType {
    GROUP_OWNER,TEACHER,INSTRUCTOR,STUDENT;
}
