package com.streamster.commons.amqp;

public enum Action {
    NEW_VIDEO, NEW_ACTION, NEW_SEARCH, UPDATE_PREFERENCES
}
